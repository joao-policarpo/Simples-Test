/**
 * @prettier
 */
export class JSONSchemaIsExpandedState {
  static Collapsed = "collapsed"

  static Expanded = "expanded"

  static DeeplyExpanded = "deeply-expanded"
}
